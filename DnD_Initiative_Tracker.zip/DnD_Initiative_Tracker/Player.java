
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Player
{
    private String name;
    private int hp;
    private int initiative;

    /**
     * Constructor for objects of class Player
     */
    public Player( String name, int hp)
    {
        this.name = name;
        this.hp = hp;
    }
    
    
    public String getName()
    {
        return name;
    }
    
    
    public int getHp()
    {
        return hp;
    }
    
    
    public int getInitiative()
    {
        return initiative;
    }
    
    
    public void incHP(int points)
    {
        hp += points;
    }
    
    
    public void decHP(int points)
    {
        hp -= points;
    }
}
