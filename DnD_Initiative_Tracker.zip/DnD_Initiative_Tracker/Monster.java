
/**
 * Write a description of class Monster here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Monster
{
    private int hp;
    private String name;
    private int initiative;

    /**
     * Constructor for objects of class Monster
     */
    public Monster(int hp)
    {
        this.hp = hp;
        
    }
    
    
    public int getHp(){
        return hp;
    }
    
    
    public String getName()
    {
        return name;
    }
    
    
    public int getIntiative()
    {
        return initiative;
    }
    
    
    public void incHP(int points)
    {
        hp += points;
    }
    
    
    public void decHP(int points)
    {
        hp -= points;
    }
}
