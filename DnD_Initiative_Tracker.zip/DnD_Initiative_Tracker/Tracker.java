
/**
 * Write a description of class Tracker here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Tracker
{
    private ArrayList<Creature> order;
    private ArrayList<Player> players;
    private ArrayList<Monster> monsters;
    private ArrayList<Creature> creatures;
    private Scanner scan = new Scanner(System.in);

    /**
     * Constructor for objects of class Tracker
     */
    public Tracker()
    {
        order = new ArrayList();
        players = new ArrayList();
        monsters = new ArrayList();
        creatures = new ArrayList();
        tracker();
    }
    
    
    /*private void addPlayer() possibly redundant method
    {
        String name;
        int hp;
        System.out.println("Enter a name: ");
        name = scan.next();
        System.out.println("Enter current HP: ");
        hp = scan.nextInt();
        players.add(new Player(name,hp));
    }
    
    
    /*private void addMonster() //possibly redundant method
    {
        int hp;
        System.out.println("Enter current HP: ");
        hp = scan.nextInt();
        monsters.add(new Monster(hp));
    }*/
    
    private void addCreature()
    {
        String name;
        int hp;
        System.out.println("Enter a name: ");
        name = scan.next();
        System.out.println("Enter current HP: ");
        hp = scan.nextInt();
        creatures.add(new Creature(name,hp));
    }
    
    
    private void tracker()
    {
        boolean quit = false;
        while(quit != true){
        displayMenu();
        int input = scan.nextInt();
        switch(input)
        {
            case 1: addCreature(); break;
            case 2: beginCombat(); break;
            case 3: quit = true; break;
        }
       }
    }
    
    
    private void displayMenu()
    {
        System.out.println("Select option");
        System.out.println("1. add creature");
        System.out.println("2. begin combat");
        System.out.println("3. quit");
    }
    
    
    private void beginCombat()
    {
        calcInitiative();
        for(int count = 0; count < order.size(); count++)
        {
            System.out.println(order.get(count).getName());
        }
        order.clear();
    }
    
    
    private void calcInitiative()
    {
        int initiative;
        for(int count = 0; count < creatures.size(); count++)
        {
            Creature next = creatures.get(count);
            System.out.println("Enter initiative of " + next.getName() + ": ");
            next.setInitiative(scan.nextInt());
            int index = 0;
            while(index <= order.size())
            {
                if(order.size() == 0) //add if array is empty
                {
                    order.add(next);
                    break;
                }
                else if(index == order.size()) //add if 
                {
                    order.ensureCapacity(order.size() + 1);
                    order.add(index, next);
                    break;
                }
                else if(order.get(index).getInitiative() <= next.getInitiative())
                {
                    order.add(index, next);
                    break;
                }
                else
                {
                    index++;
                }
            }
        }
    }
}
